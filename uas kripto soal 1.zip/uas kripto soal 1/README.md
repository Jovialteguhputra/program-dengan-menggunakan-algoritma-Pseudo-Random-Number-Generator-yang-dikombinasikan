Ini contoh aplikasi Sistem Informasi Manajemen Barang-Barang di Gudang suatu perusahaan.  Silahkan digunakan dan do'anya untuk kebaikan kita semua.
